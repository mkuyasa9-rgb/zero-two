# —͞zeroㅤTwo┊あ (Z2 Drag) — Android Build Guide

## Requirements
- Android Studio Ladybug (2024.2+) or Android SDK 35 + JDK 17
- Android device running Android 8.0 (API 26) or higher

## Build Debug / Release APK
```bash
# 1. Open this folder in Android Studio OR run via Gradle wrapper:
./gradlew assembleDebug

# Output APK:
# app/build/outputs/apk/debug/app-debug.apk

# Release APK (requires signingConfig in app/build.gradle.kts):
./gradlew assembleRelease
```

## Default Macro Calibration
- **Macro 1 (Close)**: 140px · 90ms · Delay 50ms · Smooth Arc (+5px Right)
- **Macro 2 (Mid)**: 180px · 120ms · Delay 70ms · Smooth Arc (+5px Right)
- **Macro 3 (Long)**: 220px · 150ms · Delay 80ms · Smooth Arc (+5px Right)

## Runtime Setup on Device
1. Open **Settings** inside the app and grant **Display over other apps** (`SYSTEM_ALERT_WINDOW`).
2. Tap **Grant** on **Accessibility Gesture Service** and enable **Z2 Drag Gesture Engine**.
3. Return to **Home**, toggle **Floating FIRE Button**, select Macro 1/2/3, and switch the master engine **ON**.
