package com.zerotwo.drag.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.zerotwo.drag.data.AppUiState
import com.zerotwo.drag.data.MacroDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs

class OverlayService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var windowManager: WindowManager
    private lateinit var dataStore: MacroDataStore
    private var fireView: View? = null
    private var currentState = AppUiState()

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        dataStore = MacroDataStore(applicationContext)
        startForegroundNotification()
        attachFloatingFireButton()

        scope.launch {
            dataStore.stateFlow.collectLatest { state ->
                currentState = state
            }
        }
    }

    private fun startForegroundNotification() {
        val channelId = "z2_overlay_channel"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(
                    channelId,
                    "Z2 Floating Trigger",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("—͞zeroㅤTwo┊あ")
            .setContentText("Floating FIRE trigger active")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()

        startForeground(102, notification)
    }

    private fun attachFloatingFireButton() {
        val params = WindowManager.LayoutParams(
            156,
            156,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 760
            y = 1280
        }

        val container = FrameLayout(this).apply {
            setBackgroundColor(0xFFE11D48.toInt())
        }
        val label = TextView(this).apply {
            text = "FIRE"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 13f
            gravity = Gravity.CENTER
        }
        container.addView(label)

        var initX = 0
        var initY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x
                    initY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    params.x = initX + dx
                    params.y = initY + dy
                    windowManager.updateViewLayout(container, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved && currentState.engineEnabled) {
                        Z2AccessibilityService.instance?.executeDragMacro(
                            startX = event.rawX,
                            startY = event.rawY,
                            config = currentState.activeMacro
                        )
                    }
                    true
                }
                else -> false
            }
        }

        fireView = container
        windowManager.addView(container, params)
    }

    override fun onDestroy() {
        fireView?.let { windowManager.removeView(it) }
        fireView = null
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
