package com.zerotwo.drag.data

enum class MacroSlot(val id: Int, val title: String, val rangeTag: String) {
    MACRO_1(1, "Macro 1", "Close"),
    MACRO_2(2, "Macro 2", "Mid"),
    MACRO_3(3, "Macro 3", "Long");

    companion object {
        fun fromId(id: Int): MacroSlot = entries.firstOrNull { it.id == id } ?: MACRO_1
    }
}

data class MacroConfig(
    val slot: MacroSlot,
    val distancePx: Int,
    val durationMs: Int,
    val delayMs: Int,
    val curveOffsetPx: Int = 5 // Smooth Arc, +5px Right default
)

data class AppUiState(
    val engineEnabled: Boolean = false,
    val floatingFireVisible: Boolean = false,
    val activeSlot: MacroSlot = MacroSlot.MACRO_1,
    val macros: Map<MacroSlot, MacroConfig> = defaultMacros()
) {
    val activeMacro: MacroConfig
        get() = macros[activeSlot] ?: defaultMacros().getValue(MacroSlot.MACRO_1)

    companion object {
        fun defaultMacros(): Map<MacroSlot, MacroConfig> = mapOf(
            MacroSlot.MACRO_1 to MacroConfig(
                slot = MacroSlot.MACRO_1,
                distancePx = 140,
                durationMs = 90,
                delayMs = 50,
                curveOffsetPx = 5
            ),
            MacroSlot.MACRO_2 to MacroConfig(
                slot = MacroSlot.MACRO_2,
                distancePx = 180,
                durationMs = 120,
                delayMs = 70,
                curveOffsetPx = 5
            ),
            MacroSlot.MACRO_3 to MacroConfig(
                slot = MacroSlot.MACRO_3,
                distancePx = 220,
                durationMs = 150,
                delayMs = 80,
                curveOffsetPx = 5
            )
        )
    }
}
