package com.zerotwo.drag.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zerotwo.drag.data.MacroConfig
import com.zerotwo.drag.data.MacroSlot
import com.zerotwo.drag.ui.theme.Z2Colors

@Composable
fun DragSystemScreen(
    activeMacro: MacroConfig,
    onUpdateMacro: (MacroConfig) -> Unit,
    onResetMacro: (MacroSlot) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Z2Colors.Canvas)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Drag System · ${activeMacro.slot.title}",
            color = Z2Colors.TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        // Live Preview Canvas: START FIRE -> END HEADSHOT with Red Arrow
        Card(
            colors = CardDefaults.cardColors(containerColor = Z2Colors.Surface),
            border = BorderStroke(1.dp, Z2Colors.Border),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("END HEADSHOT", color = Z2Colors.Crimson, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Smooth Arc · ${if (activeMacro.curveOffsetPx >= 0) "+${activeMacro.curveOffsetPx}" else activeMacro.curveOffsetPx}px R",
                        color = Z2Colors.TextSecondary,
                        fontSize = 11.sp
                    )
                }

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                ) {
                    val startX = size.width / 2f
                    val startY = size.height * 0.84f
                    val normalizedSpan = ((activeMacro.distancePx - 60f) / 260f).coerceIn(0f, 1f)
                    val endY = startY - (size.height * (0.28f + normalizedSpan * 0.42f))
                    val ctrlX = startX + (activeMacro.curveOffsetPx * 2.5f)
                    val ctrlY = (startY + endY) / 2f

                    val curvePath = Path().apply {
                        moveTo(startX, startY)
                        quadraticTo(ctrlX, ctrlY, startX, endY)
                    }
                    drawPath(
                        path = curvePath,
                        color = Z2Colors.Crimson,
                        style = Stroke(width = 7f, cap = StrokeCap.Round)
                    )
                    // Start Fire Point
                    drawCircle(
                        color = Z2Colors.TextPrimary,
                        radius = 12f,
                        center = Offset(startX, startY)
                    )
                    // End Headshot Target
                    drawCircle(
                        color = Z2Colors.Crimson,
                        radius = 14f,
                        center = Offset(startX, endY),
                        style = Stroke(width = 3f)
                    )
                }

                Text("START FIRE", color = Z2Colors.TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        MacroSlider(
            label = "Drag Distance",
            valueText = "${activeMacro.distancePx} px",
            value = activeMacro.distancePx.toFloat(),
            range = 60f..320f,
            onValueChange = { onUpdateMacro(activeMacro.copy(distancePx = it.toInt())) }
        )

        MacroSlider(
            label = "Swipe Duration",
            valueText = "${activeMacro.durationMs} ms",
            value = activeMacro.durationMs.toFloat(),
            range = 40f..250f,
            onValueChange = { onUpdateMacro(activeMacro.copy(durationMs = it.toInt())) }
        )

        MacroSlider(
            label = "Pre-Drag Delay",
            valueText = "${activeMacro.delayMs} ms",
            value = activeMacro.delayMs.toFloat(),
            range = 0f..150f,
            onValueChange = { onUpdateMacro(activeMacro.copy(delayMs = it.toInt())) }
        )

        MacroSlider(
            label = "Curve Arc Offset",
            valueText = "${activeMacro.curveOffsetPx} px Right",
            value = activeMacro.curveOffsetPx.toFloat(),
            range = -30f..30f,
            onValueChange = { onUpdateMacro(activeMacro.copy(curveOffsetPx = it.toInt())) }
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = { onResetMacro(activeMacro.slot) },
                border = BorderStroke(1.dp, Z2Colors.Border),
                modifier = Modifier.weight(1f)
            ) {
                Text("Reset Default", color = Z2Colors.TextPrimary)
            }
            Button(
                onClick = { onUpdateMacro(activeMacro) },
                colors = ButtonDefaults.buttonColors(containerColor = Z2Colors.Crimson),
                modifier = Modifier.weight(1f)
            ) {
                Text("Saved in DataStore", color = Color.White)
            }
        }
    }
}

@Composable
private fun MacroSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = Z2Colors.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(valueText, color = Z2Colors.Crimson, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Z2Colors.Crimson,
                activeTrackColor = Z2Colors.Crimson,
                inactiveTrackColor = Z2Colors.Border
            )
        )
    }
}
