package com.zerotwo.drag

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.zerotwo.drag.data.AppUiState
import com.zerotwo.drag.data.MacroDataStore
import com.zerotwo.drag.service.OverlayService
import com.zerotwo.drag.ui.screens.DragSystemScreen
import com.zerotwo.drag.ui.screens.HomeScreen
import com.zerotwo.drag.ui.screens.SettingsScreen
import com.zerotwo.drag.ui.screens.SplashScreen
import com.zerotwo.drag.ui.theme.Z2Colors
import com.zerotwo.drag.ui.theme.Z2Theme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dataStore = MacroDataStore(applicationContext)
        setContent {
            Z2Theme {
                Z2RootApp(dataStore = dataStore)
            }
        }
    }
}

private enum class Z2Tab(val label: String) {
    HOME("Home"),
    DRAG("Drag System"),
    SETTINGS("Settings")
}

@Composable
private fun Z2RootApp(dataStore: MacroDataStore) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by dataStore.stateFlow.collectAsState(initial = AppUiState())
    var showSplash by remember { mutableStateOf(true) }
    var currentTab by remember { mutableStateOf(Z2Tab.HOME) }

    if (showSplash) {
        SplashScreen(onFinished = { showSplash = false })
        return
    }

    Scaffold(
        containerColor = Z2Colors.Canvas,
        bottomBar = {
            NavigationBar(containerColor = Z2Colors.Surface) {
                NavigationBarItem(
                    selected = currentTab == Z2Tab.HOME,
                    onClick = { currentTab = Z2Tab.HOME },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text(Z2Tab.HOME.label) }
                )
                NavigationBarItem(
                    selected = currentTab == Z2Tab.DRAG,
                    onClick = { currentTab = Z2Tab.DRAG },
                    icon = { Icon(Icons.Default.Tune, contentDescription = "Drag System") },
                    label = { Text(Z2Tab.DRAG.label) }
                )
                NavigationBarItem(
                    selected = currentTab == Z2Tab.SETTINGS,
                    onClick = { currentTab = Z2Tab.SETTINGS },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text(Z2Tab.SETTINGS.label) }
                )
            }
        }
    ) { innerPadding ->
        androidx.compose.foundation.layout.Box(modifier = Modifier.padding(innerPadding)) {
            when (currentTab) {
                Z2Tab.HOME -> HomeScreen(
                    state = state,
                    onToggleEngine = { enabled ->
                        scope.launch { dataStore.setEngineEnabled(enabled) }
                    },
                    onSelectMacro = { slot ->
                        scope.launch { dataStore.setActiveSlot(slot) }
                    },
                    onToggleFloatingFire = { visible ->
                        scope.launch { dataStore.setFloatingFireVisible(visible) }
                        val intent = Intent(context, OverlayService::class.java)
                        if (visible) context.startForegroundService(intent) else context.stopService(intent)
                    }
                )
                Z2Tab.DRAG -> DragSystemScreen(
                    activeMacro = state.activeMacro,
                    onUpdateMacro = { updated ->
                        scope.launch { dataStore.saveMacro(updated) }
                    },
                    onResetMacro = { slot ->
                        scope.launch { dataStore.resetMacro(slot) }
                    }
                )
                Z2Tab.SETTINGS -> SettingsScreen()
            }
        }
    }
}
