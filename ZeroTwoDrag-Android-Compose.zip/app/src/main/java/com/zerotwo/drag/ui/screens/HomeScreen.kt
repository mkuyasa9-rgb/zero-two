package com.zerotwo.drag.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zerotwo.drag.data.AppUiState
import com.zerotwo.drag.data.MacroSlot
import com.zerotwo.drag.ui.theme.Z2Colors

@Composable
fun HomeScreen(
    state: AppUiState,
    onToggleEngine: (Boolean) -> Unit,
    onSelectMacro: (MacroSlot) -> Unit,
    onToggleFloatingFire: (Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Z2Colors.Canvas)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text(
            text = "—͞zeroㅤTwo┊あ",
            color = Z2Colors.TextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        // Big Master ON/OFF Control
        Card(
            colors = CardDefaults.cardColors(containerColor = Z2Colors.Surface),
            border = BorderStroke(
                width = 1.dp,
                color = if (state.engineEnabled) Z2Colors.Crimson else Z2Colors.Border
            ),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(112.dp)
                        .clip(CircleShape)
                        .background(
                            if (state.engineEnabled) Z2Colors.Crimson else Z2Colors.SurfaceAlt
                        )
                        .clickable { onToggleEngine(!state.engineEnabled) },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = "Toggle Drag Engine",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (state.engineEnabled) "ON" else "OFF",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = if (state.engineEnabled) "Gesture Engine Active" else "Engine Standby",
                    color = Z2Colors.TextSecondary,
                    fontSize = 13.sp
                )
            }
        }

        // Macro 1 / 2 / 3 Presets
        Text(
            text = "Drag Presets",
            color = Z2Colors.TextSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            MacroSlot.entries.forEach { slot ->
                val cfg = state.macros.getValue(slot)
                val selected = state.activeSlot == slot
                Card(
                    onClick = { onSelectMacro(slot) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (selected) Z2Colors.SurfaceAlt else Z2Colors.Surface
                    ),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (selected) Z2Colors.Crimson else Z2Colors.Border
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${slot.title} · ${slot.rangeTag}",
                                color = Z2Colors.TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${cfg.distancePx}px · ${cfg.durationMs}ms · Delay ${cfg.delayMs}ms",
                                color = Z2Colors.TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Text(
                            text = if (selected) "Selected" else "Select",
                            color = if (selected) Z2Colors.Crimson else Z2Colors.TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Floating FIRE Button Overlay Toggle
        Card(
            colors = CardDefaults.cardColors(containerColor = Z2Colors.Surface),
            border = BorderStroke(1.dp, Z2Colors.Border),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Floating FIRE Button",
                        color = Z2Colors.TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Overlay trigger for active macro",
                        color = Z2Colors.TextSecondary,
                        fontSize = 12.sp
                    )
                }
                Switch(
                    checked = state.floatingFireVisible,
                    onCheckedChange = onToggleFloatingFire,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Z2Colors.Crimson
                    )
                )
            }
        }
    }
}
