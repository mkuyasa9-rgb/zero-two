package com.zerotwo.drag.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zerotwo.drag.service.Z2AccessibilityService
import com.zerotwo.drag.ui.theme.Z2Colors

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val overlayGranted = Settings.canDrawOverlays(context)
    val accessibilityGranted = Z2AccessibilityService.isConnected()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Z2Colors.Canvas)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Settings & Permissions",
            color = Z2Colors.TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        PermissionCard(
            title = "Floating Overlay",
            subtitle = "Display FIRE trigger button over apps",
            granted = overlayGranted,
            onAction = {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                )
                context.startActivity(intent)
            }
        )

        PermissionCard(
            title = "Accessibility Gesture Service",
            subtitle = "Dispatch calibrated Bézier drag strokes",
            granted = accessibilityGranted,
            onAction = {
                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = Z2Colors.Surface),
            border = BorderStroke(1.dp, Z2Colors.Border),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("About", color = Z2Colors.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text("—͞zeroㅤTwo┊あ · Version 1.0.0", color = Z2Colors.TextSecondary, fontSize = 13.sp)
                Text("No Ads · No Login · Local DataStore Persistence", color = Z2Colors.TextSecondary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun PermissionCard(
    title: String,
    subtitle: String,
    granted: Boolean,
    onAction: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Z2Colors.Surface),
        border = BorderStroke(1.dp, Z2Colors.Border),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Z2Colors.TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Z2Colors.TextSecondary, fontSize = 12.sp)
                Text(
                    text = if (granted) "Granted" else "Action Required",
                    color = if (granted) Z2Colors.NominalGreen else Z2Colors.WarningAmber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (granted) Z2Colors.SurfaceAlt else Z2Colors.Crimson
                )
            ) {
                Text(if (granted) "Manage" else "Grant", color = Color.White, fontSize = 12.sp)
            }
        }
    }
}
