package com.zerotwo.drag.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zerotwo.drag.ui.theme.Z2Colors
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinished: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1300L)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Z2Colors.Canvas),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Canvas(modifier = Modifier.size(92.dp)) {
                val w = size.width
                val h = size.height
                drawRoundRect(
                    color = Z2Colors.Surface,
                    cornerRadius = CornerRadius(w * 0.22f, w * 0.22f)
                )
                drawRoundRect(
                    color = Z2Colors.Border,
                    cornerRadius = CornerRadius(w * 0.22f, w * 0.22f),
                    style = Stroke(width = 3f)
                )
                val zPath = Path().apply {
                    moveTo(w * 0.24f, h * 0.31f)
                    lineTo(w * 0.51f, h * 0.31f)
                    lineTo(w * 0.25f, h * 0.69f)
                    lineTo(w * 0.51f, h * 0.69f)
                }
                drawPath(
                    path = zPath,
                    color = Z2Colors.TextPrimary,
                    style = Stroke(width = 9f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
                val twoPath = Path().apply {
                    moveTo(w * 0.56f, h * 0.36f)
                    cubicTo(w * 0.56f, h * 0.28f, w * 0.76f, h * 0.28f, w * 0.76f, h * 0.38f)
                    lineTo(w * 0.56f, h * 0.69f)
                    lineTo(w * 0.77f, h * 0.69f)
                }
                drawPath(
                    path = twoPath,
                    color = Z2Colors.Crimson,
                    style = Stroke(width = 9f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
                drawCircle(
                    color = Z2Colors.Crimson,
                    radius = 4f,
                    center = Offset(w * 0.67f, h * 0.21f)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "—͞zeroㅤTwo┊あ",
                color = Z2Colors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Drag Macro Utility · V1",
                color = Z2Colors.TextSecondary,
                fontSize = 13.sp
            )
        }
    }
}
