package com.zerotwo.drag.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.z2DataStore: DataStore<Preferences> by preferencesDataStore(name = "z2_macro_prefs")

class MacroDataStore(private val context: Context) {

    private object Keys {
        val ENGINE_ENABLED = booleanPreferencesKey("engine_enabled")
        val FLOATING_FIRE = booleanPreferencesKey("floating_fire")
        val ACTIVE_SLOT = intPreferencesKey("active_slot")

        fun dist(slot: MacroSlot) = intPreferencesKey("m${slot.id}_dist")
        fun dur(slot: MacroSlot) = intPreferencesKey("m${slot.id}_dur")
        fun delay(slot: MacroSlot) = intPreferencesKey("m${slot.id}_delay")
        fun curve(slot: MacroSlot) = intPreferencesKey("m${slot.id}_curve")
    }

    val stateFlow: Flow<AppUiState> = context.z2DataStore.data.map { prefs ->
        val defaults = AppUiState.defaultMacros()
        val macros = MacroSlot.entries.associateWith { slot ->
            val def = defaults.getValue(slot)
            MacroConfig(
                slot = slot,
                distancePx = prefs[Keys.dist(slot)] ?: def.distancePx,
                durationMs = prefs[Keys.dur(slot)] ?: def.durationMs,
                delayMs = prefs[Keys.delay(slot)] ?: def.delayMs,
                curveOffsetPx = prefs[Keys.curve(slot)] ?: def.curveOffsetPx
            )
        }
        AppUiState(
            engineEnabled = prefs[Keys.ENGINE_ENABLED] ?: false,
            floatingFireVisible = prefs[Keys.FLOATING_FIRE] ?: false,
            activeSlot = MacroSlot.fromId(prefs[Keys.ACTIVE_SLOT] ?: 1),
            macros = macros
        )
    }

    suspend fun setEngineEnabled(enabled: Boolean) {
        context.z2DataStore.edit { it[Keys.ENGINE_ENABLED] = enabled }
    }

    suspend fun setFloatingFireVisible(visible: Boolean) {
        context.z2DataStore.edit { it[Keys.FLOATING_FIRE] = visible }
    }

    suspend fun setActiveSlot(slot: MacroSlot) {
        context.z2DataStore.edit { it[Keys.ACTIVE_SLOT] = slot.id }
    }

    suspend fun saveMacro(config: MacroConfig) {
        context.z2DataStore.edit { prefs ->
            prefs[Keys.dist(config.slot)] = config.distancePx
            prefs[Keys.dur(config.slot)] = config.durationMs
            prefs[Keys.delay(config.slot)] = config.delayMs
            prefs[Keys.curve(config.slot)] = config.curveOffsetPx
        }
    }

    suspend fun resetMacro(slot: MacroSlot) {
        val def = AppUiState.defaultMacros().getValue(slot)
        saveMacro(def)
    }
}
