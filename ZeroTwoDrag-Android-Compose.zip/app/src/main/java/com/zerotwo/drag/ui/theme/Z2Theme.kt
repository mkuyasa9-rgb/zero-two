package com.zerotwo.drag.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Z2Colors {
    val Canvas = Color(0xFF0B0B0E)
    val Surface = Color(0xFF14141A)
    val SurfaceAlt = Color(0xFF1B1B24)
    val Border = Color(0xFF272733)
    val Crimson = Color(0xFFE11D48)
    val CrimsonDark = Color(0xFF9F1239)
    val TextPrimary = Color(0xFFF4F4F6)
    val TextSecondary = Color(0xFFA1A1AA)
    val NominalGreen = Color(0xFF16A34A)
    val WarningAmber = Color(0xFFD97706)
}

private val Z2ColorScheme = darkColorScheme(
    primary = Z2Colors.Crimson,
    onPrimary = Color.White,
    background = Z2Colors.Canvas,
    onBackground = Z2Colors.TextPrimary,
    surface = Z2Colors.Surface,
    onSurface = Z2Colors.TextPrimary,
    surfaceVariant = Z2Colors.SurfaceAlt,
    onSurfaceVariant = Z2Colors.TextSecondary,
    outline = Z2Colors.Border
)

@Composable
fun Z2Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Z2ColorScheme,
        content = content
    )
}
