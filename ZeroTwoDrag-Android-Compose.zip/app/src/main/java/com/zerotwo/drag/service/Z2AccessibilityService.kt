package com.zerotwo.drag.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.zerotwo.drag.data.MacroConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class Z2AccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun executeDragMacro(
        startX: Float,
        startY: Float,
        config: MacroConfig
    ) {
        scope.launch {
            if (config.delayMs > 0) {
                delay(config.delayMs.toLong())
            }

            val endX = startX
            val endY = (startY - config.distancePx).coerceAtLeast(80f)
            val ctrlX = startX + config.curveOffsetPx.toFloat()
            val ctrlY = (startY + endY) / 2f

            val dragPath = Path().apply {
                moveTo(startX, startY)
                quadTo(ctrlX, ctrlY, endX, endY)
            }

            val stroke = GestureDescription.StrokeDescription(
                dragPath,
                0L,
                config.durationMs.toLong().coerceAtLeast(30L)
            )

            val gesture = GestureDescription.Builder()
                .addStroke(stroke)
                .build()

            dispatchGesture(gesture, null, null)
        }
    }

    companion object {
        @Volatile
        var instance: Z2AccessibilityService? = null
            private set

        fun isConnected(): Boolean = instance != null
    }
}
